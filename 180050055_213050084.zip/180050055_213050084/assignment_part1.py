import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from time import time, ctime
from operator import itemgetter
from hashlib import sha256
import random
from threading import Thread, Lock
import os

"""
We've Implemented a TRANSACTION, BLOCK and a BLOCKCHAIN using a dictionary and list. Structure for them is shown below:-

Transaction = {'id': txn_id, 'sender': self.node_id, 'receiver': receiver,'money': money}
Key 'id' is representing to unique Transaction ID.
Key 'sender' is node_id of the node who is iniating the Transaction and paying some coins to receiving node.
Key 'receiver' is node_id to whom sender is paying coins
Key 'money' is the amount of coin being transferred.

Block =  {              'id': blk_id,
                        'miner': self.node_id,
                        'txn_list': txns_to_mine,
                        'prev_block_id': self.prev_block['id'],
                        'prev_block': self.prev_block,
                        'chain_len': 1 + self.prev_block['chain_len'],
                        'prev_block_hash': prev_block_hash,
                        'timestamp': time()}
                        
Key 'id' is representing to unique Block ID.
Key 'miner' is representing node_id of node who has created this block.
Key 'txn_list' is representing all the valid transactions that are included in this block
Key 'prev_block_id' is Block id of previous block with which this block is linked.
Key 'prev_block' is the complete Block data of previous linked with current block.
Key 'chain_len' length of the chain including current Block.
Key 'prev_block_hash' is the SHA256 hash value of prev_block.
Key 'timestamp' is the time at which this block has been created .    

blockchain = {
            'genesis_block': { Same as any block structe mentioned above},
            
            'chain_of_blocks': [List of Dictionaries representing block]
            }
                               
"""

#PARAMETERS PROVIDED BY USER TO OBSERVE THE BLOCKCHAIN TREE FORMED BY DIFFERENT NODES
n = 5  #Number of nodes participate in various events of blockchain network
fast_node = 80  #How many percentage of nodes out of n would be fast; remaining would be slow as per question
total_sim = 100  # Number of events to be executed by each node
mining_reward = 50  # mining reward to be added to each node's balance whenever it successfully mines the block
tk = 2   # block_interarrival time mean
ttx = 0.5  # txn_ intearrival time mean
max_txn_per_block = 1023  # (max block size = 1 MB where empty block size = 1 KB and each TXN size is 1 KB), So max allowed txn inside block is 1023
high_mean_cpu = 0.99 #high mean less Hashing power
low_mean_cpu = 0.1  #low mean high Hashing Power

# event queue= [ [ [t,obj,event id], [t,obj,event id], [t,obj,event id], [t,obj,event id] ] , [[t,obj,event id], [t,obj,event id]] ,
# [[t,obj,event id], [t,obj,event id] . . . . . ] ,
# [[t,obj,event id]] . . . . . .]
event_queue = []  # Queue at index i is the event queue of node i
blk_id = 1
txn_id = 1

node_list = []  # Nodelist at index i stores Node i (Node id is 0,1,..,n-1)

"""
Function to generate the SHA256 hash value of all the content of 'prev_block' dictionary.
"""
def get_block_prev_block_hash(block_id, prev_block):
    prev_block_hash = None
    if (not block_id == 0):
        prev_block_hash = sha256(str(prev_block).encode('utf-8')).hexdigest()
    return prev_block_hash
"""
Enqueue is function to insert the event list on the event queue. Here, We Ensuring that 1st index of event queue always
holds the event which needs to be executed 1st based on its execution time.
"""
def Enqueue(index, event_list):
    with lock:
        event_queue[index].insert(0, event_list)
        event_queue[index] = (sorted(event_queue[index], key=itemgetter(0)))
"""
Every time this function invokes it returns the event whose time of execution is arrived.
"""
def Dequeue(index):  # Popping out event from the event queue when its execution time comes
    with lock:
        event = event_queue[index].pop(0)
        return event
"""
Function to ensure that node always mine on the block which has longer chain among all the blocks he has recieved earlier.
"""
def Mine_On_Block_with_longest_chain(index,len_of_chain):
    with lock:
        events = event_queue[index]
        ev_index = 0
        while ev_index < len(events):
            if events[ev_index][2] == 3 and events[ev_index][1].prev_block['chain_len'] < len_of_chain:
                events.pop(events.index(events[ev_index]))
                return 1
            ev_index += 1
        return 0
"""
Function to write the event logs to the file corresponding to the nodes.
"""
def Write_to_File(file_name, Content_to_write):
    file_handler = open(file_name, 'a')
    file_handler.write(Content_to_write)
    file_handler.close()


class Generate_Block:
    """
    Class Initialization for Generate_Block class.
    """
    def __init__(self, id, tstamp, event_exec_time, prev_block):
        self.temp1_blk = prev_block             #Prev Block Dictionary to which this block is getting linked
        self.execution_time = event_exec_time   #Event execution time; Time when the Block is finally created
        self.timestamp = tstamp                 #Event Creation Time; Time when this event to "Generate a Block" is created
        self.node_id = id                       #Node id of Miner or the node who will generate the block
        self.prev_block = prev_block            #Prev Block Dictionary to which this block is getting linked

    """
    function : SimulationRun()
    This function simulates the execution of event created for Generating a Block.
    """
    def Generate_Block_Simulation(self):
        all_transactions = []

        """
        "all_transactions" is a list in which we're storing all the Transactions till now included to blockchain 
        of this node.
        """
        while self.temp1_blk['id'] > 0:
            for i in self.temp1_blk['txn_list']:
                all_transactions.insert(0, i)
            self.temp1_blk = self.temp1_blk['prev_block']

        txns_to_mine = []
        node = node_list[self.node_id]
        t_index = 0
        """
        "txns_to_mine" is a list of all the Transactions from the "pending_transaction" list to which we'll put
         here in a Block we generating now.
        """
        while t_index<len(node.pending_transaction):
            if (node.pending_transaction[t_index] not in all_transactions):
                txns_to_mine.insert(0, node.pending_transaction[t_index])
            t_index += 1
        """
        Every Block will contain atleast 1 Transaction except for Genesis Block. Here we're ensuring the same.
        """
        if (len(txns_to_mine) > max_txn_per_block):
            txns_to_mine = txns_to_mine[:max_txn_per_block]
        min_txn_per_block = 1
        """
        Here, we're simulating that last node is trying to add the Transaction to the list "txn_to_mine" which is 
        already present in the blockchain.(i.e. trying to double spend). Later we'll ensure no "double spend" should
        not able to get on the block.
        """
        is_double_spent = False
        if (self.node_id == n - 1):
            if len(all_transactions) != 0:
                is_double_spent = True
                txns_to_mine.append(all_transactions[0])
        """
        Here, we're finding Block Interarrival Time from the exponential distribution using the mean time(tk) provided 
        by the user.
        """
        blk_int_time = np.random.exponential(scale=tk)
        """
        Below is the Code segment generating a new block. Ensuring there is no double spend happend. Also adding the
        mining reward to the miner node for this block. Also writing this event log to the file. 
        """
        file_name = "NODE " + str(self.node_id) + ".txt"
        block = self.prev_block
        #Ensuring there is atleast 1 transaction to put on the Block
        if (len(txns_to_mine) > min_txn_per_block):
            with lock:
                global blk_id
                blk_id = blk_id + 1
                prev_block_hash = get_block_prev_block_hash(blk_id, self.prev_block)
                #Creating the Block
                block = {'id': blk_id,
                        'miner': self.node_id,
                        'txn_list': txns_to_mine,
                        'prev_block_id': self.prev_block['id'],
                        'prev_block': self.prev_block,
                        'chain_len': 1 + self.prev_block['chain_len'],
                        'prev_block_hash': prev_block_hash,
                        'timestamp': time()}
            #Checking for double spend and adding mining reward to the miner node
            if is_double_spent == False:
                for i in node_list:
                    i.balance_list[self.node_id] += mining_reward
            #Adding the newly created block to the Blockchain of the current node i.e miner himself
            node.blockchain['chain_of_blocks'].append(block)
            #Writing the event log to the file corresponding to the miner node.
            eventlog = "TIMESTAMP : " + ctime(time()) + "       BLOCK GENERATED{ Chain length: " + str((self.prev_block['chain_len']) + 1) + " Mining Reward Added :" + str(mining_reward) + "}\n"
            Write_to_File(file_name, eventlog)
            eventlog = "TIMESTAMP : " + ctime(time()) + "       Node " + str(self.node_id) + "       Current Balance : " + str(node.balance_list[self.node_id]) + " BTC\n"
            Write_to_File(file_name, eventlog)

            """
            Creating an event to forward this newly created block to its neighbor nodes based on latency between the
            this node and the neighbor node.
            """
            node_index = 0
            peers = node.neigbors
            while (node_index < len(peers)):
                #calculating the latency between current mining node and its selected neighbor
                blk_travel_time = node.Cal_Latencies(node_list[peers[node_index]], False, len(txns_to_mine))
                #Block receive time based on the Block latency and the Interblock arrival time
                blk_recv_time =  self.execution_time + blk_travel_time
                ev = Forward_Block(block, peers[node_index], self.execution_time, blk_recv_time)
                #Putitng the event to the event queue
                Enqueue(peers[node_index], [blk_recv_time, ev, 4])
                ##Writing the event log to the file corresponding to this node.
                file_name = "NODE " + str(self.node_id) + ".txt"
                eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT4 CREATED{ FORWARD [GENERATED BLOCK] TO NODE " + str(peers[node_index]) + " with latency " + str(blk_travel_time) + "sec }       BY{ NODE" + str(self.node_id) + "}\n"
                Write_to_File(file_name, eventlog)
                node_index += 1

        else:
            #Writing to the file when Miner doesn't have any transaction to put on the Block
            eventlog = "TIMESTAMP : " + ctime(time()) + "       !!!!!CANNOT GENERATE A BLOCK : NEED ATLEAST 1 TRANSACTION!!!!! \n"
            Write_to_File(file_name, eventlog)

        #This node again create new event to Generate a Block
        blk_event_ex_time =  self.execution_time + blk_int_time
        ev = Generate_Block(self.node_id, self.execution_time,blk_event_ex_time, block)
        Enqueue(self.node_id, [blk_event_ex_time, ev, 3])
        #Writing the log of Creating a new event to "Generate a Block" to the file corresponding to this node.
        file_name = "NODE " + str(self.node_id) + ".txt"
        eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT3 CREATED{ Generate BLOCK at " + ctime(blk_event_ex_time) + " }       BY{ NODE" + str(self.node_id) + "}\n"
        Write_to_File(file_name, eventlog)


class Forward_Block:
    def __init__(self, blk, id, timestamp, run_time):
        self.blk = blk
        self.node_id = id
        self.timestamp = timestamp
        self.execution_time = run_time
    """
    
    """
    def Forward_Block_Simulation(self):
        node = node_list[self.node_id]

        if ((self.blk in node.blockchain['chain_of_blocks'])):  # If Block already receieved then ignore this. Loopless broadcasting to prevent redundant blocks
            return

        flag1 = 0
        for i in node.blockchain['chain_of_blocks']:
            if self.blk['prev_block_id'] == i['id']:
                flag1 = 1
        if (flag1 == 0):
            for i in node.par_list:
                if (i['id'] == self.blk['prev_block_id'] or i['prev_block_id'] == self.blk['id']):
                    node.blockchain['chain_of_blocks'].append(i)
                    node.par_list.pop(node.par_list.index(i))

                    file_name = "NODE " + str(self.node_id) + ".txt"
                    eventlog = "TIMESTAMP : " + ctime(time()) + "       BLOCK FORWARDED{ [VALID BLOCK] created by " + str(i['miner']) + " }       Recieved by NODE " + str(self.node_id) + "\n"
                    Write_to_File(file_name, eventlog)

                    flag1 = 1
            if flag1 == 0:
                node.par_list.append(self.blk)
                return


        t = []
        temp_block = self.blk['prev_block']
        while (temp_block['id'] != 0):
            for s_txns in temp_block['txn_list']:
                t.append(s_txns)
            temp_block = temp_block['prev_block']

        for s_txns in self.blk['txn_list']:
            if s_txns in t:

                file_name = "NODE " + str(self.node_id) + ".txt"
                eventlog = "TIMESTAMP : " + ctime(time()) + "       !!!!INVALID!!!!!!!INVALID!!!!!!!!BLOCK FORWARDED{ [INVALID BLOCK] created by " + str(self.blk['miner']) + " }       Recieved by NODE " + str(self.node_id) + "\n"
                Write_to_File(file_name, eventlog)
                return  # If double spend detected then return

        # If received a block with an invalid transaction (transaction that have'nt been broadcasted)
        for i in self.blk['txn_list']:
            if i not in node.pending_transaction:
                return

        # Add recieved block to its blockchain
        node.blockchain['chain_of_blocks'].append(self.blk)

        file_name = "NODE " + str(self.node_id) + ".txt"
        eventlog = "TIMESTAMP : " + ctime(time()) + "       BLOCK FORWARDED{ [VALID BLOCK] created by " + str(self.blk['miner']) + " }       Recieved by NODE " + str(self.node_id) + "\n"
        Write_to_File(file_name, eventlog)

        # If received block has longer chain length than the previous block's chain length, the node was mining. Node x shifts mining to this longer chain
        rec_len = self.blk['chain_len']

        flag = Mine_On_Block_with_longest_chain(self.node_id, rec_len)
        if (flag == 1):
            Tk_Mean = 1/tk
            Tk_delay = (node.cpu * Tk_Mean)*100
            blk_int_time = np.random.exponential(scale=Tk_delay)
            ev = Generate_Block(self.node_id, self.execution_time, self.execution_time + blk_int_time, self.blk)
            Enqueue(self.node_id, [self.execution_time + blk_int_time, ev, 3])

            file_name = "NODE " + str(self.node_id) + ".txt"
            eventlog = "TIMESTAMP : " + ctime(time()) + "      Found longer chain on a recieved block{ [RESHEDULING Mining on a new BLOCK] at "+ ctime(self.execution_time + blk_int_time)  +" }"+ "\n"
            Write_to_File(file_name, eventlog)

        # Generates event Block receive by its connected peers. Event will reach the peer at time depending on latency between both node x and that peer
        node_index = 0
        peers = node.neigbors
        while (node_index < len(peers)):
            blk_travel_time = node.Cal_Latencies(node_list[peers[node_index]], False, len(self.blk['txn_list']))
            blk_recv_time = self.execution_time + blk_travel_time
            ev = Forward_Block(self.blk, peers[node_index], self.execution_time, blk_recv_time)
            Enqueue(peers[node_index], [blk_recv_time, ev, 4])

            file_name = "NODE " + str(self.node_id) + ".txt"
            eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT4 CREATED{ FORWARD [GENERATED BLOCK] TO NODE " + str(peers[node_index]) + " with latency " + str(blk_travel_time) + "sec }       BY{ NODE" + str(self.node_id) + "}\n"
            Write_to_File(file_name, eventlog)
            node_index += 1

class Node:
    """
    class Initialization of class Node. This basically Initializing each node with its own Blockchain with Genesis
    Block. All node have their own "balance_list" which stores the balace of node i at index i of this list.
    """
    def __init__(self, node_id, is_fast, peers, cpu):
        self.node_id = node_id                          # Unique Node_id starting from 0 to N-1
        self.balance_list = [100 for x in range(n)]     #Initializing every node coin balance with 100 Bitcoin

        #Writing to file about This the first event when node is created and initialized with the Coin balance.
        file_name = "NODE " + str(self.node_id) + ".txt"
        eventlog = "TIMESTAMP : " + ctime(time()) + "       Node " + str(self.node_id) + " initialized with" + str(self.balance_list[self.node_id]) + " BTC\n"
        Write_to_File(file_name, eventlog)

        self.is_fast = is_fast                          #Assigning node as Fast or Slow. is_fast = True for fast and Slow for otherwise.
        self.cpu = cpu                                  #Assigning the CPU power value between 0.1 to 0.99

        #Creating Seperate Blockchain instance for every node
        self.blockchain = {
            'genesis_block': {'id': 0,
                              'miner': self.node_id,
                              'txn_list': [],
                              'prev_block_id': -1,
                              'prev_block': None,
                              'chain_len': 0,
                              'prev_block_hash': get_block_prev_block_hash(0, None)},

            'chain_of_blocks': [{'id': 0,
                                 'miner': self.node_id,
                                 'txn_list': [],
                                 'prev_block_id': -1,
                                 'prev_block': None,
                                'chain_len': 0,
                                'prev_block_hash': get_block_prev_block_hash(0, None)}]}
        self.par_list = []
        self.neigbors = peers   #List of all the neighbors to this node

        event_queue.append([])  #Initializing event queue for this node with empty list

        self.pending_transaction = []  #This is the list for containg all the pending transaction this node has.(Transaction pool)
        self.counter = 0
    """
    
    """
    def longest_chain(self):
        longest_chain = []
        max_length = 0
        max_length_block = self.blockchain['genesis_block']

        blk = 0
        while (blk < len(self.blockchain['chain_of_blocks'])):
            if self.blockchain['chain_of_blocks'][blk] != self.blockchain['genesis_block']:
                if (self.blockchain['chain_of_blocks'][blk]['chain_len'] > max_length):
                    max_length = self.blockchain['chain_of_blocks'][blk]['chain_len']
                    max_length_block = self.blockchain['chain_of_blocks'][blk]
                elif (self.blockchain['chain_of_blocks'][blk]['chain_len'] < max_length):
                    print("")
                else:
                    if (self.blockchain['chain_of_blocks'].index(self.blockchain['chain_of_blocks'][blk]) > self.blockchain['chain_of_blocks'].index(max_length_block)):
                        max_length = self.blockchain['chain_of_blocks'][blk]['chain_len']
                        max_length_block = self.blockchain['chain_of_blocks'][blk]
            blk += 1

        temp = max_length_block

        while (temp['id'] != 0):
            longest_chain.append(temp)
            temp = temp['prev_block']

        longest_chain.append(self.blockchain['genesis_block'])

        return longest_chain

    """
    Function to Calculate Transaction latency(Transaction size is assumed 1KB) and Block Latency with varying block size.
    """
    def Cal_Latencies(self, other, isTxnLat, size):
        if other.is_fast == self.is_fast == True:
            C_ij = 100 * (2 ** 20)  # 100Mbps in bits if Both nodes are fast
        else:
            C_ij = 5 * (2 ** 20)  # 5Mbps in bits if atleast One node is slow

        P_ij = (random.uniform(10, 500)) / 1000  # generate a uniform prop delay(10,500)

        if isTxnLat == True:
            msg_size = size * (2 ** 10) * 8  # 1KB in bits
        else:
            msg_size = size * (2 ** 10) * 8  # 1KB in bits
        D_ij = 96 * (2 ** 10) / C_ij    #mean for dij 96kbits/cij
        #Randomly choosing from an exponenetial distribution with mean provided above
        D_ij = np.random.exponential(scale=D_ij)
        L_ij = P_ij + (msg_size / C_ij) + D_ij  #Final latency calculated as per the form mentioned in question
        return L_ij

    """
    Function to start the simulation in which events to created. Event for  random transaction generation and
    event for generate blocks are created.
    """
    def SimulationRun(self):
        """
        Here, we're finding Transaction Interarrival Time from the exponential distribution using the mean time(ttx)
        provided by the user and Creating an event to "GENERATE TRANSACTION"
        """
        txn_int_time = np.random.exponential(scale=ttx)
        t = time() + txn_int_time #Event execution Time; when the actually Transaction will be created.
        # Creating an event to "GENERATE TRANSACTION"
        ev = Generate_Transaction(self.node_id, time(), t)
        #Putting the event "Generate_Transaction on the event queue of this node"
        Enqueue(self.node_id, [t, ev, 1])

        # Writing the log of Creating a new event "Generate_Transaction" to the file corresponding to this node.
        file_name = "NODE " + str(self.node_id) + ".txt"
        eventlog = "TIMESTAMP : " + ctime(time()) +"        EVENT1 CREATED{ Generate Transaction at " + ctime(t) + " }       BY{ NODE" + str(self.node_id) + "}\n"
        Write_to_File(file_name, eventlog)

        """
        Here, we're finding Block Interarrival Time from the exponential distribution using the mean time(tk) provided 
        by the user.
        """
        blk_int_time = np.random.exponential(scale=tk)
        t = time() + blk_int_time
        #Creating an event to "GENERATE BLOCK"
        ev = Generate_Block(self.node_id, time(), t, self.blockchain['genesis_block'])
        # Putting the event "Generate_Block" on the event queue of this node"
        Enqueue(self.node_id, [t, ev, 3])

        # Writing the log of Creating a new event "Generate_Block" to the file corresponding to this node.
        file_name = "NODE " + str(self.node_id) + ".txt"
        file1 = open(file_name, 'a')
        eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT3 CREATED{ Generate BLOCK at " + ctime(t) + " }       BY{ NODE" + str(self.node_id) + "}\n"
        Write_to_File(file_name, eventlog)

        """
        Here, We're running the all the events stored in the event queue of each node whenever queue is not empty.
        Ensuring that the event execution time has arrived. Every event is assigned with event number.
        1 = Generate_Transaction
        2 = Forward_Transaction
        3 = Generate_Block
        4 = Forward_Block
        """
        while (self.counter <= total_sim):
            queue_not_empty = len(event_queue[self.node_id]) > 0    #Checking whethe Event Queue is Empty or Not
            time_to_execute_event = event_queue[self.node_id][0][0] <= time()  #Checking whether the execution time for the event has been arrived or not.
            if (queue_not_empty and time_to_execute_event):
                event = Dequeue(self.node_id) #event is list [time_of_execution, obj, event id]
                if event[2] == 1:
                    event[1].Generate_Transaction_Simulation()
                    self.counter += 1
                elif event[2] == 2:
                    event[1].Forward_Transaction_Simulation()
                    self.counter += 1
                elif event[2] == 3:
                    event[1].Generate_Block_Simulation()
                    self.counter += 1
                elif event[2] == 4:
                    event[1].Forward_Block_Simulation()
                    self.counter += 1


class Generate_Transaction:
    """
    Initialization of Generate_Transaction class with node_id of node creating transanction, time of transaction or
    event creation and the final time at which Transaction Generation event will be created.
    """
    def __init__(self, node_id, timestamp, run_time):
        self.node_id = node_id
        self.timestamp = timestamp
        self.run_time = run_time
    """
    Funtion to create the event "Generate Transaction" Here we're choosing the receiver node randomly to whom sender node
    should pay. Creating a new event to "Forward Transaction" and event to create new "Generate Transaction"
    """
    def Generate_Transaction_Simulation(self):
        node = node_list[self.node_id]  #Object of Node class for node_id

        #Random selection of Receiver node
        receiver = random.choice([x for x in range(n)])
        while (receiver == self.node_id):
            receiver = random.choice([x for x in range(n)])
        #Random selection of amount to transfer
        money = random.uniform(1, node.balance_list[self.node_id])

        file_name = "NODE " + str(self.node_id) + ".txt"
        # Checking whether the Sender node has sufficient amount or not for this transaction
        if (node.balance_list[self.node_id] >= money):
            with lock:
                global txn_id
                txn_id += 1
                #Creating Transaction with unique Txn id each time.
                t = {'id': txn_id, 'sender': self.node_id, 'receiver': receiver,'money': money}

                #Updating Balance of Sender and Receiver after the transaction in Sender's Balance List
                node.balance_list[self.node_id] -= money
                node.balance_list[receiver] += money
            #Including this newly created transaction to the "pending_transaction" list of sender node.
            node.pending_transaction.append(t)

            # Writing the log of Creating a new event "Generate_Transaction" to the file corresponding to this node.
            eventlog = "TIMESTAMP : " + ctime(time()) +"        TRANSANCTION GENERATED{ Node " + str(self.node_id) + " pays " + str(money) + "BTC to Node:" + str(receiver) +"}\n"
            Write_to_File(file_name, eventlog)
            eventlog = "TIMESTAMP : " + ctime(time()) + "       Node " + str(self.node_id) + "       Current Balance : " + str(node.balance_list[self.node_id]) + " BTC" + os.linesep
            Write_to_File(file_name, eventlog)

            """
            Creating an event to forward this newly created transaction to its neighbor nodes based on latency between the
            this node and the neighbor node.
            """
            node_index = 0
            peers = node.neigbors
            while (node_index < len(peers)):
                # Transaction Latency between Sender node and its neighbor
                txn_travel_time = node.Cal_Latencies(node_list[peers[node_index]], True, 1)
                #Event created for "Forward Transaction"
                ev = Forward_Transaction(t, peers[node_index], self.run_time, self.run_time + txn_travel_time)
                #Putting the event to the event queue of neighbor node
                Enqueue(peers[node_index], [self.run_time + txn_travel_time, ev, 2])

                # Writing the log of Creating a new event "Forward_Transaction" to the file corresponding to this node.
                file_name = "NODE " + str(self.node_id) + ".txt"
                eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT2 CREATED{ FORWARD [GENERATED TRANSACTION] TO NODE " + str(peers[node_index]) + " with latency " + str(txn_travel_time) + "sec }       BY{ NODE" + str(self.node_id) + "}\n"
                Write_to_File(file_name, eventlog)
                node_index += 1

        else:
            # Writing to the file corresponding to this node that it doesn't have balance for this transaction.
            eventlog = "TIMESTAMP : " + ctime(time()) + "       INSUFFICIENT BALANCE!!!!!        need more "+str(node.balance_list[self.node_id] - money)+"BTC for this transaction.\n"
            Write_to_File(file_name, eventlog)

        """
        Here, we're finding Transaction Interarrival Time from the exponential distribution using the mean time(ttx)
        provided by the user and Creating an event to "GENERATE TRANSACTION"
        """
        txn_int_time = np.random.exponential(scale=ttx)
        event_ex_time =  self.run_time + txn_int_time
        ev = Generate_Transaction(self.node_id, self.run_time,event_ex_time)
        Enqueue(self.node_id, [self.run_time + txn_int_time, ev, 1])

        # Writing the log of Creating a new event "Generate_Transaction" to the file corresponding to this node.
        file_name = "NODE " + str(self.node_id) + ".txt"
        eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT1 CREATED{ Generate Transaction at " + ctime(event_ex_time)  + " }       BY{ NODE" + str(self.node_id) + "}\n"
        Write_to_File(file_name, eventlog)


class Forward_Transaction:
    def __init__(self, txn, node_id, timestamp, run_time):
        self.node_id = node_id
        self.timestamp = timestamp
        self.run_time = run_time
        self.txn = txn  # txn = {'id':,'sender': , 'receiver':, 'money':}
    """
    """
    def Forward_Transaction_Simulation(self):
        node = node_list[self.node_id]

        if node.balance_list[self.txn['sender']] < self.txn['money']:  # txn = {'id':,'sender': , 'receiver':, 'money':}
            return

        if self.txn in node.pending_transaction:  # txn = {'id':,'sender': , 'receiver':, 'money':}
            return

        node.pending_transaction.append(self.txn)

        node.balance_list[self.txn['sender']] -= self.txn['money']  # txn = {'id':,'sender': , 'receiver':, 'money':}
        node.balance_list[self.txn['receiver']] += self.txn['money']  # txn = {'id':,'sender': , 'receiver':, 'money':}

        file_name = "NODE " + str(self.node_id)+".txt"
        eventlog = "TIMESTAMP : " + ctime(time()) + "       TRANSANCTION FORWARDED{ Node " + str(self.txn['sender']) + " pays " + str(self.txn['money']) + "BTC to Node:" + str(self.txn['receiver']) + " } Received By NODE "+str(self.node_id)+"\n"
        Write_to_File(file_name, eventlog)

        node_index = 0
        peers = node.neigbors
        while (node_index < len(peers)):
            txn_travel_time = node.Cal_Latencies(node_list[peers[node_index]], True, 1)  # CHANGED FUNCTION
            ev = Forward_Transaction(self.txn, peers[node_index], self.run_time, self.run_time + txn_travel_time)
            Enqueue(peers[node_index], [self.run_time + txn_travel_time, ev, 2])

            file_name = "NODE " + str(self.node_id)+".txt"
            eventlog = "TIMESTAMP : " + ctime(time()) + "       EVENT2 CREATED{ FORWARD [RECEIVED TRANSACTION] TO NODE " + str(peers[node_index]) + " with latency " + str(txn_travel_time) + "sec }       BY{ NODE" + str(self.node_id) + "}\n"
            Write_to_File(file_name, eventlog)
            node_index += 1



if __name__ == "__main__":
    #Removing the Text file corresponding to the NODE; if it exists already because of last run.
    for i in range(n):
        file_name = "NODE " + str(i) + ".txt"
        if os.path.exists(file_name):
            os.remove(file_name)
    #Creating the Graph
    network_graph = nx.Graph()
    #adding the nodes to the Graph based on the argument of n provided by the user
    for i in range(n):
        network_graph.add_node(i)
    #Randomly connecting the graph by adding edges between randomly selected nodes.
    while nx.is_connected(network_graph) == False:
        c1 = random.choice(list(network_graph.nodes()))
        c2 = random.choice(list(network_graph.nodes()))
        if c1 != c2 and network_graph.has_edge(c1, c2) == 0: #Ensuring edge already doesn't exist between the selected nodes.
            network_graph.add_edge(c1, c2)

    Adj_List =[]    #Adjacency list storing the node connection details. i index stores the neighbors of node i.
    for i in range(n):
        Adj_List.append({'NODE '+str(i):list(network_graph.neighbors(i))})

    #Drawing the Randomly connected graph
    nx.draw(network_graph, with_labels=1)
    sr = 'Randomly_Connected_Nodes' + '.png' #Name of the png file
    plt.savefig(sr) #Saving the Graph
    plt.show()  #Plotting the Graph

    print('Neighbours of each node \n',Adj_List)

    #Calculating How many nodes will be fast nodes based on the percentage provided by the user
    fast_node = int((fast_node * n) / 100)
    f = True

    #Initializing the node objects and storing them on "node_list" i index stores the Node object of node i
    for i in range(n):
        if i >= fast_node-1:
            f = False #Initial desired(fast_node) number of  nodes are designated as fast nodes
        cpu_mean = random.uniform(low_mean_cpu, high_mean_cpu) #Every nodes are randomly assigned a CPU power between (0.1, 0.99)
        node_list.append(Node(i, f, list(network_graph.neighbors(i)), cpu_mean))


    lock = Lock() #Lock for ensuring synchronization to avoid race condition
    mythreads = list(np.zeros(10))

    #Creating Threads for every nodes and Starting them
    for i in range(n):
        mythreads[i] = Thread(target=node_list[i].SimulationRun)
        with lock:
            print("\nThread ", i, 'Started\n')
        mythreads[i].start()
    #Waiting for all threads to join
    for i in range(n):
        mythreads[i].join()

    """
    Plotting the Blockchain tree for each nodes and printing the "Block" details to console.
    """
    num_blocks_gen_by_each_miner = []
    for i in range(n):
        count = 0

        tree = node_list[i].blockchain['chain_of_blocks']
        T = nx.Graph()  #Graph for tree
        blocks = []  # each block as a node
        blcks = []
        for x in range(0, len(tree)):
            blocks.append(tree[x]['id'])    #Adding the "Block Id" for all the Blocks stored by this node
            blcks.append((tree[x]['id'],tree[x]['miner'],tree[x]['prev_block_id'])) #Fetching and storing some details of every block to print them on console

            if i == tree[x]['miner']: #counting how many blocks is mined by node i
                count += 1

        num_blocks_gen_by_each_miner.append(count)
        print('--------------------------------------------------------------------------')
        #Printing Block ID, Miner, Prev Block to show who has created this block and with which block this is linked
        print('blocks connection details for node ',i,blcks)
        print('--------------------------------------------------------------------------')
        for block in blocks:
            T.add_node(block) #Adding nodes to the Tree graph

        for j in range(1, len(tree)):
            if (tree[j]['prev_block']['id'] == 0):
                T.add_edge(tree[j]['id'], tree[0]['id'])    #Adding edge to the nodes(here Block) which is linked to genesis block
            else:
                T.add_edge(tree[j]['id'], tree[j]['prev_block']['id']) #Adding edges to all other blocks other than genesis block
        nx.draw(T,with_labels=True, font_size=10)   #Drawing the tree Graph
        sr = 'blockchaintree_' + f'{i}' + '.png'    #Name of the png image of tree
        plt.savefig(sr)                             #Saving the png image
        plt.show()                                  #Plotting the png image to the new window


    """
    Plotting the longest chain tree for each blockchain nodes and printing the entire "Blockchain" dictionary for each node to console.
    """
    num_blocks_in_longst_chain = []
    for i in range(n):
        count = 0
        s = node_list[i].longest_chain()    #Longest Chain function storing the blocks which part of the longest chain
        print('******************************************BLOCKCHAIN INFORMATION*************************************************')
        print(node_list[i].blockchain)
        print('***********************************************BLOCKCHAIN INFORMATION********************************************')



        blks = []  # each block as a node of graph
        for x in range(0, len(s)):
            blks.append(s[x]['id'])

            if i == s[x]['miner']: #counting how many blocks is mined by node i
                count += 1
        num_blocks_in_longst_chain.append(count)  # storing the number of blocks in longest chain of node i at index i.
        print('blocks for node ',i,blks)

        L_C = nx.Graph()    #Creating Graph for longest chain
        for block in blks:
          L_C.add_node(block)       #Adding blocks as a node of tree for longest chain

        for j in range(len(s)- 1):
            L_C.add_edge(blks[j], blks[j + 1])  #Adding edges between them
        nx.draw(L_C, with_labels=1)
        sr = 'longestchain_' + f'{i}' + '.png'  #Name of the png image of tree
        plt.savefig(sr)                          #Saving the png image
        plt.show()                               #Plotting the png image to the new window


"""
Calculating the ratio of the number of blocks generated by each node in Longest chain of the tree to the total number 
of blocks it generates at the end of simulation.
"""
for i in range(n):
    if node_list[i].is_fast == True:
        print('\n\nNODE',i,'     FAST NODE')
    else:
        print('\n\nNODE', i, '     SLOW NODE')

    # if node_list[i].cpu > 0.5:
    #     print('NODE', i, '     LOW CPU NODE        CPU MEAN',node_list[i].cpu)
    # else:
    #     print('NODE', i, '     HIGH CPU NODE        CPU MEAN',node_list[i].cpu)
    print('Total Number of Blocks in longest chain tree of Node', i, '    ', num_blocks_in_longst_chain[i])
    print('Total Number of Blocks generated by Node',i,'    ',num_blocks_gen_by_each_miner[i])

    print('Ratio of Blocks      ',(num_blocks_in_longst_chain[i]/num_blocks_gen_by_each_miner[i]))
